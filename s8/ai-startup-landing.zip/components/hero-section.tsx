"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  const [currentText, setCurrentText] = useState(0)
  const dynamicTexts = ["Propulsé par l'IA", "Automatisation intelligente", "Concluez plus vite"]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentText((prev) => (prev + 1) % dynamicTexts.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section
      id="accueil"
      className="relative min-h-screen flex items-center bg-gradient-to-br from-white via-[#f4f4f4]/30 to-white overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=800')] bg-repeat opacity-20"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20">
                <span className="text-[#fe5c02] font-semibold text-sm">🚀 Nouvelle génération d'agents IA</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#0d1b2a] leading-tight">
                Révolutionnez votre
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] min-h-[1.2em]">
                  {dynamicTexts[currentText]}
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-gray-600 leading-relaxed max-w-2xl">
                4 agents IA collaborent intelligemment pour transformer votre cycle de vente : de la prospection à la
                signature, automatisez chaque étape avec une précision inégalée.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] hover:from-[#ff8a42] hover:to-[#fdbb8d] text-white font-semibold px-8 py-4 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                Essayez gratuitement maintenant
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>

              <Button
                variant="outline"
                size="lg"
                className="border-2 border-[#0d1b2a] text-[#0d1b2a] hover:bg-[#0d1b2a] hover:text-white px-8 py-4 rounded-full transition-all duration-300 bg-transparent"
              >
                <Play className="mr-2 h-5 w-5" />
                Voir la démo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-200">
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-[#fe5c02]">+300%</div>
                <div className="text-sm text-gray-600">Taux de conversion</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-[#fe5c02]">24/7</div>
                <div className="text-sm text-gray-600">Disponibilité</div>
              </div>
              <div className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-[#fe5c02]">-80%</div>
                <div className="text-sm text-gray-600">Temps de cycle</div>
              </div>
            </div>
          </div>

          {/* Right Content - Hero Image */}
          <div className="relative">
            <div className="relative z-10">
              <Image
                src="/placeholder.svg?height=600&width=600"
                alt="Agents IA collaboratifs"
                width={600}
                height={600}
                className="w-full h-auto rounded-2xl shadow-2xl"
                priority
              />
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] rounded-full opacity-20 animate-pulse"></div>
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-gradient-to-r from-[#ff8a42] to-[#fdbb8d] rounded-full opacity-10 animate-pulse delay-1000"></div>
          </div>
        </div>
      </div>
    </section>
  )
}

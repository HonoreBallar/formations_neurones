import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, Star, Zap } from "lucide-react"

export function PricingSection() {
  const plans = [
    {
      name: "Starter",
      price: "99",
      period: "/mois",
      description: "Parfait pour les petites équipes qui débutent",
      features: [
        "Agent Prospecteur inclus",
        "Jusqu'à 500 prospects/mois",
        "Support email",
        "Intégrations de base",
        "Rapports mensuels",
      ],
      cta: "Commencer gratuitement",
      popular: false,
      color: "border-gray-200",
    },
    {
      name: "Professional",
      price: "299",
      period: "/mois",
      description: "La solution complète pour les équipes en croissance",
      features: [
        "Les 4 agents IA inclus",
        "Prospects illimités",
        "Support prioritaire 24/7",
        "Toutes les intégrations",
        "Analytics avancées",
        "Formation personnalisée",
        "API complète",
      ],
      cta: "Essai gratuit 14 jours",
      popular: true,
      color: "border-[#fe5c02] ring-2 ring-[#fe5c02]/20",
    },
    {
      name: "Enterprise",
      price: "Sur mesure",
      period: "",
      description: "Solution personnalisée pour les grandes entreprises",
      features: [
        "Agents IA personnalisés",
        "Volume illimité",
        "Support dédié",
        "Intégrations sur mesure",
        "SLA garanti",
        "Formation équipe complète",
        "Conformité entreprise",
      ],
      cta: "Contactez-nous",
      popular: false,
      color: "border-gray-200",
    },
  ]

  return (
    <section id="tarifs" className="py-20 lg:py-32 bg-gradient-to-b from-white to-[#f4f4f4]/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20 mb-6">
            <span className="text-[#fe5c02] font-semibold text-sm">💰 Tarifs Transparents</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0d1b2a] mb-6">
            Choisissez votre plan d'automatisation
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Des tarifs simples et transparents pour toutes les tailles d'entreprise. Commencez gratuitement et évoluez
            selon vos besoins.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative ${plan.color} ${plan.popular ? "transform scale-105 shadow-2xl" : "shadow-lg"} transition-all duration-300 hover:shadow-xl bg-white`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center">
                    <Star className="h-4 w-4 mr-1" />
                    Plus populaire
                  </div>
                </div>
              )}

              <CardHeader className="text-center pb-8">
                <div className="mb-4">
                  {plan.popular && (
                    <div className="inline-flex p-3 rounded-2xl bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] text-white mb-4">
                      <Zap className="h-6 w-6" />
                    </div>
                  )}
                  <h3 className="text-2xl font-bold text-[#0d1b2a] mb-2">{plan.name}</h3>
                  <p className="text-gray-600">{plan.description}</p>
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl lg:text-5xl font-bold text-[#0d1b2a]">
                      {plan.price === "Sur mesure" ? "" : "€"}
                      {plan.price}
                    </span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <Check className="h-5 w-5 text-[#fe5c02] mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full py-3 rounded-full font-semibold transition-all duration-300 ${
                    plan.popular
                      ? "bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] hover:from-[#ff8a42] hover:to-[#fdbb8d] text-white transform hover:scale-105"
                      : "border-2 border-[#fe5c02] text-[#fe5c02] hover:bg-[#fe5c02] hover:text-white"
                  }`}
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Money Back Guarantee */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center px-6 py-3 bg-green-50 border border-green-200 rounded-full">
            <Check className="h-5 w-5 text-green-600 mr-2" />
            <span className="text-green-800 font-semibold">Garantie satisfait ou remboursé 30 jours</span>
          </div>
        </div>

        {/* FAQ Preview */}
        <div className="mt-16 text-center">
          <h3 className="text-xl font-bold text-[#0d1b2a] mb-4">Des questions ?</h3>
          <p className="text-gray-600 mb-6">
            Notre équipe est là pour vous accompagner dans le choix de votre solution.
          </p>
          <Button
            variant="outline"
            className="border-[#fe5c02] text-[#fe5c02] hover:bg-[#fe5c02] hover:text-white px-8 py-3 rounded-full bg-transparent"
          >
            Planifier une démo personnalisée
          </Button>
        </div>
      </div>
    </section>
  )
}

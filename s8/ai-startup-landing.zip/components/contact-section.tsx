"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Send } from "lucide-react"

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <section id="contact" className="py-20 lg:py-32 bg-gradient-to-b from-[#f4f4f4]/50 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20 mb-6">
            <span className="text-[#fe5c02] font-semibold text-sm">📞 Contactez-nous</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0d1b2a] mb-6">
            Prêt à transformer vos ventes ?
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Discutons de vos besoins et découvrez comment nos agents IA peuvent révolutionner votre approche commerciale
            dès aujourd'hui.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <Card className="shadow-2xl border-0 bg-white">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-[#0d1b2a] mb-6">Envoyez-nous un message</h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                    Nom complet *
                  </label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#fe5c02] focus:border-transparent transition-all duration-300"
                    placeholder="Votre nom complet"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Email professionnel *
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#fe5c02] focus:border-transparent transition-all duration-300"
                    placeholder="votre.email@entreprise.com"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                    Message *
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#fe5c02] focus:border-transparent transition-all duration-300 resize-none"
                    placeholder="Décrivez vos besoins et objectifs commerciaux..."
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] hover:from-[#ff8a42] hover:to-[#fdbb8d] text-white font-semibold py-4 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <Send className="mr-2 h-5 w-5" />
                  Envoyer le message
                </Button>
              </form>

              <p className="text-sm text-gray-500 mt-4 text-center">Nous vous répondons sous 24h maximum</p>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-[#0d1b2a] mb-6">Autres moyens de nous contacter</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] rounded-lg text-white">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#0d1b2a] mb-1">Email</h4>
                    <p className="text-gray-600">contact@agentflow.ai</p>
                    <p className="text-sm text-gray-500">Réponse sous 24h</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] rounded-lg text-white">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#0d1b2a] mb-1">Téléphone</h4>
                    <p className="text-gray-600">+33 1 23 45 67 89</p>
                    <p className="text-sm text-gray-500">Lun-Ven 9h-18h</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] rounded-lg text-white">
                    <MapPin className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-[#0d1b2a] mb-1">Adresse</h4>
                    <p className="text-gray-600">
                      123 Avenue de l'Innovation
                      <br />
                      75001 Paris, France
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-r from-[#fe5c02]/5 to-[#ff8a42]/5 border border-[#fe5c02]/20">
              <CardContent className="p-6">
                <h4 className="font-bold text-[#0d1b2a] mb-4">Actions rapides</h4>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start border-[#fe5c02]/30 text-[#fe5c02] hover:bg-[#fe5c02] hover:text-white bg-transparent"
                  >
                    📅 Planifier une démo
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-[#fe5c02]/30 text-[#fe5c02] hover:bg-[#fe5c02] hover:text-white bg-transparent"
                  >
                    💬 Chat en direct
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-[#fe5c02]/30 text-[#fe5c02] hover:bg-[#fe5c02] hover:text-white bg-transparent"
                  >
                    📚 Documentation
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Response Time */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-green-500 rounded-full mr-3 animate-pulse"></div>
                <span className="text-green-800 font-semibold">Notre équipe est en ligne et prête à vous aider !</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react"
import Image from "next/image"

export function TestimonialsSection() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0)

  const testimonials = [
    {
      name: "Marie Dubois",
      role: "Directrice Commerciale",
      company: "TechCorp",
      image: "/placeholder.svg?height=80&width=80",
      rating: 5,
      text: "AgentFlow a transformé notre approche commerciale. Nos taux de conversion ont augmenté de 300% en seulement 3 mois. L'automatisation intelligente nous fait gagner un temps précieux.",
      results: "+300% conversion",
    },
    {
      name: "Pierre Martin",
      role: "CEO",
      company: "InnovateLab",
      image: "/placeholder.svg?height=80&width=80",
      rating: 5,
      text: "Incroyable ! Les agents IA d'AgentFlow gèrent notre prospection 24/7. Nous avons réduit notre cycle de vente de 80% tout en améliorant la qualité de nos leads.",
      results: "-80% cycle de vente",
    },
    {
      name: "Sophie Leroy",
      role: "VP Sales",
      company: "GrowthCo",
      image: "/placeholder.svg?height=80&width=80",
      rating: 5,
      text: "La collaboration entre les 4 agents est remarquable. Chaque prospect reçoit un suivi personnalisé et notre équipe peut se concentrer sur les deals à forte valeur.",
      results: "+250% ROI",
    },
  ]

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-20 lg:py-32 bg-gradient-to-b from-[#f4f4f4]/50 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20 mb-6">
            <span className="text-[#fe5c02] font-semibold text-sm">💬 Témoignages Clients</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0d1b2a] mb-6">
            Ils ont révolutionné leurs ventes
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez comment nos clients ont transformé leur performance commerciale grâce à nos agents IA
            collaboratifs.
          </p>
        </div>

        {/* Main Testimonial */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="bg-white shadow-2xl border-0 overflow-hidden">
            <CardContent className="p-8 lg:p-12">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                <div className="flex-shrink-0">
                  <div className="relative">
                    <Image
                      src={testimonials[currentTestimonial].image || "/placeholder.svg"}
                      alt={testimonials[currentTestimonial].name}
                      width={120}
                      height={120}
                      className="rounded-full border-4 border-[#fe5c02]/20"
                    />
                    <div className="absolute -top-2 -right-2 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] rounded-full p-2">
                      <Quote className="h-4 w-4 text-white" />
                    </div>
                  </div>
                </div>

                <div className="flex-1 text-center lg:text-left">
                  <div className="flex justify-center lg:justify-start mb-4">
                    {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>

                  <blockquote className="text-lg lg:text-xl text-gray-700 mb-6 leading-relaxed italic">
                    "{testimonials[currentTestimonial].text}"
                  </blockquote>

                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                    <div>
                      <div className="font-bold text-[#0d1b2a] text-lg">{testimonials[currentTestimonial].name}</div>
                      <div className="text-gray-600">
                        {testimonials[currentTestimonial].role} • {testimonials[currentTestimonial].company}
                      </div>
                    </div>

                    <div className="mt-4 lg:mt-0">
                      <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20">
                        <span className="text-[#fe5c02] font-bold text-sm">
                          {testimonials[currentTestimonial].results}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={prevTestimonial}
            className="rounded-full border-[#fe5c02]/30 hover:bg-[#fe5c02] hover:text-white transition-all duration-300 bg-transparent"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div className="flex gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentTestimonial ? "bg-[#fe5c02] scale-125" : "bg-gray-300 hover:bg-gray-400"
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={nextTestimonial}
            className="rounded-full border-[#fe5c02]/30 hover:bg-[#fe5c02] hover:text-white transition-all duration-300 bg-transparent"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-[#fe5c02] mb-2">500+</div>
            <div className="text-gray-600">Clients satisfaits</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-[#fe5c02] mb-2">98%</div>
            <div className="text-gray-600">Taux de satisfaction</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-[#fe5c02] mb-2">24/7</div>
            <div className="text-gray-600">Support client</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-[#fe5c02] mb-2">15min</div>
            <div className="text-gray-600">Temps de setup</div>
          </div>
        </div>
      </div>
    </section>
  )
}

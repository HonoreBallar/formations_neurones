import { Card, CardContent } from "@/components/ui/card"
import { Search, MessageCircle, Handshake, FileText } from "lucide-react"
import Image from "next/image"

export function AgentsSection() {
  const agents = [
    {
      icon: Search,
      name: "Agent Prospecteur",
      description: "Lead generation intelligente",
      details:
        "Identifie et qualifie automatiquement vos prospects idéaux grâce à l'analyse comportementale et aux données de marché.",
      color: "from-blue-500 to-blue-600",
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      icon: MessageCircle,
      name: "Agent Communicant",
      description: "Messages & emails personnalisés",
      details:
        "Génère et envoie des communications ultra-personnalisées adaptées à chaque prospect selon son profil et ses besoins.",
      color: "from-green-500 to-green-600",
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      icon: Handshake,
      name: "Agent Négociateur",
      description: "Objections & offres optimisées",
      details:
        "Traite les objections en temps réel et ajuste automatiquement les offres pour maximiser les chances de conversion.",
      color: "from-purple-500 to-purple-600",
      image: "/placeholder.svg?height=300&width=400",
    },
    {
      icon: FileText,
      name: "Agent Contractuel",
      description: "Signature & relances automatiques",
      details:
        "Gère le processus de signature électronique et effectue des relances intelligentes jusqu'à la finalisation du contrat.",
      color: "from-orange-500 to-orange-600",
      image: "/placeholder.svg?height=300&width=400",
    },
  ]

  return (
    <section id="agents" className="py-20 lg:py-32 bg-gradient-to-b from-white to-[#f4f4f4]/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-[#fe5c02]/10 to-[#ff8a42]/10 rounded-full border border-[#fe5c02]/20 mb-6">
            <span className="text-[#fe5c02] font-semibold text-sm">🤖 Nos 4 Agents IA</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0d1b2a] mb-6">
            Une équipe IA qui ne dort jamais
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez comment nos 4 agents IA spécialisés collaborent pour transformer chaque étape de votre cycle de
            vente en succès automatisé.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {agents.map((agent, index) => (
            <Card
              key={index}
              className="group hover:shadow-2xl transition-all duration-500 border-0 bg-white/80 backdrop-blur-sm overflow-hidden"
            >
              <CardContent className="p-0">
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={agent.image || "/placeholder.svg"}
                    alt={agent.name}
                    width={400}
                    height={300}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div
                    className={`absolute inset-0 bg-gradient-to-t ${agent.color} opacity-20 group-hover:opacity-30 transition-opacity duration-300`}
                  ></div>
                </div>

                <div className="p-8">
                  <div className="flex items-center mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${agent.color} text-white mr-4`}>
                      <agent.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-[#0d1b2a]">{agent.name}</h3>
                      <p className="text-[#fe5c02] font-semibold">{agent.description}</p>
                    </div>
                  </div>

                  <p className="text-gray-600 leading-relaxed">{agent.details}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Collaboration Flow */}
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold text-[#0d1b2a] mb-8">Collaboration intelligente en temps réel</h3>
          <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-8">
            {agents.map((agent, index) => (
              <div key={index} className="flex items-center">
                <div className={`p-4 rounded-full bg-gradient-to-r ${agent.color} text-white shadow-lg`}>
                  <agent.icon className="h-8 w-8" />
                </div>
                {index < agents.length - 1 && (
                  <div className="hidden md:block w-12 h-0.5 bg-gradient-to-r from-[#fe5c02] to-[#ff8a42] mx-4"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
